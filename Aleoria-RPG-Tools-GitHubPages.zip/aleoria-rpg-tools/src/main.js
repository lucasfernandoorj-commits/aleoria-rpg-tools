import OBR from "@owlbear-rodeo/sdk";
import "./style.css";

const EXTENSION_ID = "com.aleoria.rpg-tools";
const META_KEY = `${EXTENSION_ID}/campaign`;
const LOCAL_KEY = "aleoria-rpg-tools-local-v1";
const ATTRS = ["FOR", "DES", "RES", "INT", "SAB", "CAR"];
const CONDITIONS = [
  ["Em Vantagem", "Posição favorável; vantagem nos ataques."],
  ["Em Desvantagem", "Ataques com desvantagem."],
  ["Exposto", "−2 na CA."], ["Protegido", "+2 na CA."],
  ["Despercebido", "Não foi notado; ataques dele e contra ele têm vantagem. Atacar revela a posição."],
  ["Despreparado", "Não percebeu o atacante; ataques contra ele têm vantagem."],
  ["Observado", "Sob atenção direta; não pode se esconder."],
  ["Preparado", "+2 no teste ou ataque preparado."],
  ["Sob Pressão", "Desvantagem em testes que exigem calma ou precisão."],
  ["Cansado", "Leve: −1 em testes físicos e −1 pé de deslocamento."],
  ["Exausto", "Média: desvantagem em testes físicos e deslocamento pela metade."],
  ["Ferido", "PV iguais ou menores que a metade."],
  ["Atordoado", "Média: perde Ação Principal e Reação até o fim do próximo turno."],
  ["Concentrado", "+2 no teste da ação e vantagem para manter magias."],
  ["Distraído", "Leve: desvantagem em Percepção, Concentração e Controle."],
  ["Abalado", "Leve: −1 em testes mentais e sociais."],
  ["Em Sintonia", "Próxima magia custa 1 PE a menos (mínimo 1)."],
  ["Mana Forçada", "PE ≤ ¼ do máximo: desvantagem em Controle."],
  ["Sob Ressaca de Mana", "Média: sem reações mágicas, desvantagem em Controle e −2 na DT das magias."],
  ["Drenado", "Leve: perde 1d6 PE imediatamente."],
  ["Silenciado", "Média: não pode falar nem conjurar efeitos que exigem palavras."],
  ["Desequilibrado", "Leve: −1 CA; próximo ataque contra o alvo ganha +2."],
  ["Imobilizado", "Média: deslocamento 0 e −2 CA; escapa com Brutalidade ou Acrobacia."],
  ["Empurrado", "Deslocado contra a vontade."],
  ["Derrubado", "Leve: corpo a corpo contra ele tem vantagem; à distância, desvantagem. Levantar custa Ação de Movimento."],
  ["Lento", "Leve: −2 pés de deslocamento."],
  ["Sem Reação", "Leve: sem reação até o início do próximo turno."],
  ["Deslocado", "Leve: −1 em ataques e Reflexos."],
  ["Instável", "Leve: −1 CA e −1 pé de deslocamento."],
  ["Cego", "Leve: desvantagem em ataques e testes visuais; ataques contra ele têm vantagem."],
  ["Enfraquecido", "Leve: −2 em todo dano causado."],
  ["Marcado", "Leve: próximo ataque ou magia contra o alvo ganha +2."],
  ["Desarmado", "Soltou a arma; sacar novamente custa Ação Menor."],
  ["Sangrando", "Leve: 1d4 por turno; Média: 1d6 por turno. Medicina DT 10, cura ou fim da duração."],
  ["Queimado", "1d4 de dano de fogo por turno; apaga com Ação Menor ou água."],
  ["Molhado", "Leve: apaga Queimado e sofre +1d6 de dano elétrico."],
  ["Eletrificado", "Leve: perde Reação e tem desvantagem em Reflexos."],
  ["Congelado", "Média: deslocamento pela metade e desvantagem em Reflexos e ataques."],
  ["Corroído", "Média: −1 CA ou ataque da arma até ser reparado."],
  ["Envenenado", "Média: desvantagem em ataques e testes de FOR e DES."],
  ["Entorpecido", "Leve: −2 em Reflexos, Percepção e iniciativa."],
  ["Paralisado", "Média: perde Ação Principal, Movimento e Reação; ataques corpo a corpo contra ele têm vantagem."],
  ["Doente", "Média: descansos recuperam só metade de PV e PE; fica Cansado."],
  ["Amedrontado", "Leve: desvantagem em ataques e testes enquanto vê a fonte; não pode se aproximar voluntariamente."],
  ["Confuso", "Leve: desvantagem na próxima ação; Média: no início do turno, 1–2 age ao acaso, 3–6 normalmente."],
  ["Dominado", "Crítica: obedece a comandos simples da fonte."],
  ["Desesperado", "Leve: Ação Principal vai contra inimigo mais próximo; desvantagem em Controle."],
  ["Amaldiçoado", "Média: desvantagem em um tipo de teste definido pela maldição."],
  ["Súplica", "Leve: próxima cura ou bênção recebida ganha +1d6."],
  ["Condenação", "Leve: próximo ataque ou oração sagrada contra o alvo causa +1d6."],
  ["Intercessão", "Leve: próximo dano recebido é reduzido em 1d6."],
  ["Consagração", "Leve: aliados na área +1 CA; profanos −1 nos ataques."]
];
const DEFAULT = { characters: [], initiative: [], round: 1, active: 0, log: [] };
let state = structuredClone(DEFAULT);
let obrReady = false;
let syncing = false;
let saveTimer;

const $ = (selector, root = document) => root.querySelector(selector);
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const mod = (value) => Math.floor((Number(value || 10) - 10) / 2);
const fmtMod = (value) => value >= 0 ? `+${value}` : String(value);
const uid = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const rollDie = (sides) => Math.floor(Math.random() * sides) + 1;

function persist() {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(state));
  if (!obrReady || syncing) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try { await OBR.scene.setMetadata({ [META_KEY]: state }); }
    catch (error) { console.warn("Não foi possível sincronizar com a cena:", error); }
  }, 180);
}
function loadLocal() {
  try { return JSON.parse(localStorage.getItem(LOCAL_KEY)) || structuredClone(DEFAULT); }
  catch { return structuredClone(DEFAULT); }
}
async function loadScene() {
  try {
    const metadata = await OBR.scene.getMetadata();
    if (metadata?.[META_KEY]) state = normalize(metadata[META_KEY]);
    else state = loadLocal();
    await OBR.scene.setMetadata({ [META_KEY]: state });
    render();
  } catch (error) { console.warn(error); }
}
function normalize(value) {
  return { ...structuredClone(DEFAULT), ...(value || {}), characters: Array.isArray(value?.characters) ? value.characters : [], initiative: Array.isArray(value?.initiative) ? value.initiative : [], log: Array.isArray(value?.log) ? value.log : [] };
}
function addLog(message) {
  state.log.unshift({ id: uid(), at: new Date().toLocaleTimeString("pt-BR", {hour:"2-digit", minute:"2-digit"}), message });
  state.log = state.log.slice(0, 30);
}
function nav(tab) {
  document.querySelectorAll("[data-tab]").forEach(el => el.classList.toggle("active", el.dataset.tab === tab));
  document.querySelectorAll(".panel").forEach(el => el.classList.toggle("active", el.id === `panel-${tab}`));
}

function render() {
  renderOverview(); renderCharacters(); renderInitiative(); renderConditions(); renderLog(); refreshTestSelect();
  $("#round-label").textContent = state.round;
  $("#sync-state").textContent = obrReady ? "Cena sincronizada" : "Modo local · abra uma sala para sincronizar";
  $("#sync-dot").classList.toggle("online", obrReady);
}
function renderOverview() {
  $("#stat-characters").textContent = state.characters.length;
  $("#stat-round").textContent = state.round;
  $("#stat-pv").textContent = state.characters.reduce((sum,c)=>sum+Number(c.pv||0),0);
  $("#stat-pe").textContent = state.characters.reduce((sum,c)=>sum+Number(c.pe||0),0);
  const active = state.initiative[state.active];
  $("#active-turn").textContent = active ? `${characterName(active.characterId)} · ${active.value}` : "Nenhum turno ativo";
  $("#quick-characters").innerHTML = state.characters.slice(0,5).map(c => `<div class="quick-row"><span class="avatar">${esc((c.name||"?").slice(0,1).toUpperCase())}</span><span class="quick-name">${esc(c.name)}</span><span class="muted small">${Number(c.pv||0)}/${Number(c.maxPv||0)} PV</span></div>`).join("") || `<p class="empty">Adicione seu primeiro personagem na aba Fichas.</p>`;
}
function characterName(id) { return state.characters.find(c=>c.id===id)?.name || "Personagem removido"; }
function renderCharacters() {
  $("#character-list").innerHTML = state.characters.map(c => {
    const stats = ATTRS.map(a=>`<div class="attr"><b>${a}</b><strong>${Number(c[a]||10)}</strong><small>${fmtMod(mod(c[a]))}</small></div>`).join("");
    const armor = Number(c.armorBonus||0), shield = Number(c.shieldBonus||0);
    const reflex = mod(c.DES) + Number(c.reflexSkill||0);
    const ca = (armor > 0 ? 10 + Math.floor(mod(c.RES)/2) + armor + Math.max(Number(c.armorProf||0), reflex) : 10 + reflex) + shield + (c.exposed ? -2 : 0) + (c.protected ? 2 : 0);
    const loadPenalty = Math.floor(Number(c.load||0)/4);
    const movement = Math.max(0, Number(c.baseMove||5) + Math.max(0,mod(c.DES)) + Math.floor(Number(c.athletics||0)/2) - loadPenalty - (c.heavyArmor ? 2 : 0));
    return `<article class="character-card" data-id="${c.id}">
      <div class="character-head"><div class="avatar big">${esc((c.name||"?").slice(0,1).toUpperCase())}</div><div class="grow"><h3>${esc(c.name)}</h3><p>${esc(c.race||"Raça não definida")} · ${esc(c.className||"Classe não definida")} · Nível ${Number(c.level||1)}</p></div><button class="icon-btn edit-char" title="Editar ficha">✎</button><button class="icon-btn delete-char" title="Excluir ficha">×</button></div>
      <div class="resource-line"><span>PV <b>${Number(c.pv||0)} / ${Number(c.maxPv||0)}</b></span><div class="bar"><i style="width:${percent(c.pv,c.maxPv)}%"></i></div><button class="mini-btn adjust" data-resource="pv" data-delta="-1">−</button><button class="mini-btn adjust" data-resource="pv" data-delta="1">+</button></div>
      <div class="resource-line blue"><span>PE <b>${Number(c.pe||0)} / ${Number(c.maxPe||0)}</b></span><div class="bar"><i style="width:${percent(c.pe,c.maxPe)}%"></i></div><button class="mini-btn adjust" data-resource="pe" data-delta="-1">−</button><button class="mini-btn adjust" data-resource="pe" data-delta="1">+</button></div>
      <div class="attr-grid">${stats}</div>
      <div class="derived"><span>CA <b>${ca}</b></span><span>Mov. <b>${movement} pés</b></span><span>Carga <b>${Number(c.load||0)}/${6+mod(c.FOR)+Number(c.bagBonus||0)}</b></span></div>
      <div class="card-actions"><button class="secondary-btn add-init">＋ Iniciativa</button><button class="secondary-btn show-cond">Condições</button><button class="secondary-btn quick-roll">Rolar teste</button></div>
    </article>`;
  }).join("") || `<div class="empty-card"><div class="empty-icon">♙</div><b>Nenhuma ficha criada</b><p>Crie fichas para controlar PV, PE, atributos, CA, movimento e carga.</p><button class="primary-btn" id="empty-add">Criar personagem</button></div>`;
}
function percent(current,max) { return Math.max(0,Math.min(100,Number(max)>0?Number(current)/Number(max)*100:0)); }
function renderInitiative() {
  const list = [...state.initiative].sort((a,b)=>Number(b.value)-Number(a.value));
  $("#initiative-list").innerHTML = list.map((entry,index)=>`<div class="initiative-row ${state.initiative[state.active]?.id===entry.id?"turn-active":""}" data-id="${entry.id}"><span class="turn-number">${index+1}</span><div class="grow"><b>${esc(characterName(entry.characterId))}</b><small>${entry.note?esc(entry.note):"Participante"}</small></div><input class="initiative-value" type="number" value="${Number(entry.value)||0}" aria-label="Iniciativa"/><button class="icon-btn remove-init" title="Remover">×</button></div>`).join("") || `<p class="empty">Adicione personagens à iniciativa para começar o combate.</p>`;
}
function renderConditions() {
  $("#condition-grid").innerHTML = CONDITIONS.map(([name,desc])=>`<button class="condition-chip" data-condition="${esc(name)}" title="${esc(desc)}">${esc(name)}</button>`).join("");
  const selected = $("#condition-target").value;
  $("#condition-target").innerHTML = state.characters.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
  if (state.characters.some(c=>c.id===selected)) $("#condition-target").value=selected;
  $("#applied-conditions").innerHTML = state.characters.map(c=>`<div class="condition-person"><b>${esc(c.name)}</b><div class="condition-tags">${(c.conditions||[]).map((cond,i)=>`<span class="condition-tag">${esc(cond.name)} <small>${esc(cond.level)}</small><button data-remove-cond="${c.id}" data-index="${i}">×</button></span>`).join("") || `<small class="muted">Sem condições</small>`}</div></div>`).join("") || `<p class="empty">Crie uma ficha para aplicar condições.</p>`;
}
function renderLog() {
  $("#combat-log").innerHTML = state.log.map(item=>`<div class="log-entry"><time>${esc(item.at)}</time><span>${esc(item.message)}</span></div>`).join("") || `<p class="empty">As rolagens e ações aparecerão aqui.</p>`;
}

function openCharacter(character = null) {
  const c = character || {id:uid(),name:"",race:"Humano",className:"Guerreiro",level:1,FOR:10,DES:10,RES:10,INT:10,SAB:10,CAR:10,pv:10,maxPv:10,pe:5,maxPe:5,armorBonus:0,armorProf:0,reflexSkill:0,shieldBonus:0,baseMove:5,athletics:0,load:0,bagBonus:0,heavyArmor:false,weaponProf:0,damageBonus:0,conditions:[]};
  const form = $("#character-form");
  form.dataset.id = c.id;
  $("#character-modal-title").textContent = character ? "Editar personagem" : "Nova ficha";
  $("#character-fields").innerHTML = `
    <div class="form-grid"><label class="span-2">Nome<input name="name" required value="${esc(c.name)}" placeholder="Nome do aventureiro"></label>
    <label>Raça<input name="race" value="${esc(c.race)}"></label><label>Classe<input name="className" value="${esc(c.className)}"></label><label>Nível<input name="level" type="number" min="1" value="${Number(c.level||1)}"></label>
    ${ATTRS.map(a=>`<label>${a}<input name="${a}" type="number" min="1" max="20" value="${Number(c[a]??10)}"></label>`).join("")}
    <div class="section-label span-2">Recursos</div><label>PV atual<input name="pv" type="number" min="0" value="${Number(c.pv||0)}"></label><label>PV máximo<input name="maxPv" type="number" min="1" value="${Number(c.maxPv||1)}"></label><label>PE atual<input name="pe" type="number" min="0" value="${Number(c.pe||0)}"></label><label>PE máximo<input name="maxPe" type="number" min="1" value="${Number(c.maxPe||1)}"></label>
    <div class="section-label span-2">Defesa e deslocamento</div><label>Bônus da armadura<input name="armorBonus" type="number" value="${Number(c.armorBonus||0)}"></label><label>Proficiência na armadura<input name="armorProf" type="number" value="${Number(c.armorProf||0)}"></label><label>Bônus de Reflexos (perícia)<input name="reflexSkill" type="number" value="${Number(c.reflexSkill||0)}"></label><label>Bônus do escudo<input name="shieldBonus" type="number" value="${Number(c.shieldBonus||0)}"></label><label>Deslocamento base (pés)<input name="baseMove" type="number" value="${Number(c.baseMove??5)}"></label><label>Bônus de Atletismo<input name="athletics" type="number" value="${Number(c.athletics||0)}"></label><label>Carga ocupada (espaços)<input name="load" type="number" min="0" value="${Number(c.load||0)}"></label><label>Bônus de bolsa<input name="bagBonus" type="number" min="0" value="${Number(c.bagBonus||0)}"></label><div class="section-label span-2">Ataques</div><label>Proficiência na arma<input name="weaponProf" type="number" value="${Number(c.weaponProf||0)}"></label><label>Bônus de dano<input name="damageBonus" type="number" value="${Number(c.damageBonus||0)}"></label>
    <label class="check-label span-2"><input name="heavyArmor" type="checkbox" ${c.heavyArmor?"checked":""}> Usa armadura pesada (−2 pés de deslocamento)</label>
    </div><p class="hint">Os PV/PE máximos são editáveis porque o cálculo completo depende dos dados-base específicos da raça e classe. O livro orienta rolar os dados por nível ou usar médias arredondadas para cima.</p>`;
  $("#character-modal").showModal();
}

function addInitiative(characterId, value = null) {
  if (state.initiative.some(e=>e.characterId===characterId)) return;
  const c = state.characters.find(x=>x.id===characterId); if(!c) return;
  const score = value ?? (rollDie(20) + mod(c.DES) + Number(c.reflexSkill||0));
  state.initiative.push({id:uid(),characterId,value:score,note:""});
  state.initiative.sort((a,b)=>b.value-a.value); state.active=0;
  addLog(`${c.name} entrou na iniciativa com ${score}.`); persist(); render();
}
function nextTurn() {
  if (!state.initiative.length) return;
  state.active = (state.active + 1) % state.initiative.length;
  if (state.active === 0) state.round += 1;
  const active = state.initiative[state.active];
  addLog(`Rodada ${state.round}: turno de ${characterName(active.characterId)}.`);
  persist(); render();
}
function rollDice(expression) {
  const match = String(expression).trim().match(/^(\d*)d(4|6|8|10|12|20)([+-]\d+)?$/i);
  if (!match) return null;
  const count = Math.max(1,Math.min(30,Number(match[1]||1))), sides=Number(match[2]), bonus=Number(match[3]||0);
  const rolls=Array.from({length:count},()=>rollDie(sides));
  return {rolls,bonus,total:rolls.reduce((a,b)=>a+b,0)+bonus,expression:`${count}d${sides}${bonus?fmtMod(bonus):""}`};
}
function showRoll(result,label="Rolagem") {
  if(!result) return;
  $("#roll-result-label").textContent=label;
  $("#roll-total").textContent=result.total;
  $("#roll-breakdown").textContent=`${result.expression}: [${result.rolls.join(" + ")}] ${result.bonus?`${result.bonus>=0?"+":"−"} ${Math.abs(result.bonus)}`:""}`;
  addLog(`${label}: ${result.expression} = ${result.total}.`); persist(); renderLog();
}

$("#app").innerHTML = `
  <header class="topbar"><div class="brand-mark">✦</div><div class="brand"><strong>ALEÓRIA</strong><small>RPG TOOLS <span>v1.0</span></small></div><div class="grow"></div><span id="sync-dot" class="sync-dot"></span><span id="sync-state" class="sync-state">Carregando...</span></header>
  <main>
    <section class="hero"><div><div class="eyebrow">FERRAMENTAS DO MESTRE</div><h1>Que a aventura <em>comece.</em></h1><p>Seu painel de campanha para o mundo de Aleória.</p></div><div class="hero-sigil">ᚨ</div></section>
    <nav class="tabs"><button class="active" data-tab="overview">Visão geral</button><button data-tab="characters">Fichas</button><button data-tab="initiative">Combate</button><button data-tab="dice">Dados</button><button data-tab="conditions">Condições</button></nav>
    <section id="panel-overview" class="panel active">
      <div class="section-heading"><div><div class="eyebrow">RESUMO DA SESSÃO</div><h2>Painel da campanha</h2></div><button class="primary-btn" id="new-character">＋ Nova ficha</button></div>
      <div class="stats-grid"><div class="stat-card"><span>PERSONAGENS</span><b id="stat-characters">0</b><small>fichas cadastradas</small></div><div class="stat-card"><span>RODADA</span><b id="stat-round">1</b><small>combate atual</small></div><div class="stat-card"><span>PV SOMADOS</span><b id="stat-pv">0</b><small>PV atuais</small></div><div class="stat-card"><span>PE SOMADOS</span><b id="stat-pe">0</b><small>PE atuais</small></div></div>
      <div class="two-col"><div class="panel-card"><div class="card-title"><h3>Grupo de aventureiros</h3><button class="text-btn" data-goto="characters">Ver fichas →</button></div><div id="quick-characters"></div></div><div class="panel-card turn-card"><div class="eyebrow">TURNO ATUAL</div><h3 id="active-turn">Nenhum turno ativo</h3><p>Avance a ordem de iniciativa durante o combate.</p><button class="secondary-btn full" data-goto="initiative">Abrir combate</button></div></div>
      <div class="panel-card log-card"><div class="card-title"><h3>Registro da sessão</h3><span class="muted small">Mais recente primeiro</span></div><div id="combat-log"></div></div>
    </section>
    <section id="panel-characters" class="panel"><div class="section-heading"><div><div class="eyebrow">HERÓIS E NPCS</div><h2>Fichas de personagem</h2></div><button class="primary-btn" id="new-character-2">＋ Nova ficha</button></div><div id="character-list" class="character-list"></div></section>
    <section id="panel-initiative" class="panel"><div class="section-heading"><div><div class="eyebrow">ORDEM DE AÇÃO</div><h2>Controle de combate</h2></div><div class="round-pill">RODADA <b id="round-label">1</b></div></div><div class="combat-controls"><button class="primary-btn" id="next-turn">Próximo turno ↗</button><button class="secondary-btn" id="new-round">Reiniciar rodada</button><button class="secondary-btn" id="clear-init">Limpar ordem</button></div><div class="panel-card"><div class="card-title"><h3>Iniciativa</h3><button class="text-btn" id="add-init-select">＋ Adicionar personagem</button></div><div id="initiative-list"></div></div><div class="panel-card"><h3>Rolagem de iniciativa</h3><p class="muted small">Regra: 1d20 + modificador de DES + bônus de Reflexos. O livro indica que Reflexos também entra na iniciativa.</p><button class="secondary-btn" id="roll-all-init">Rolar iniciativa de todos</button></div><div class="panel-card"><h3>Ataque e dano</h3><div class="form-grid"><label>Atacante<select id="attack-character"></select></label><label>Atributo do ataque<select id="attack-attribute"><option>FOR</option><option>DES</option><option>INT</option><option>SAB</option></select></label><label>Dado de dano<select id="attack-die"><option value="6">1d6 · arma leve</option><option value="8">1d8 · arma média</option><option value="12">1d12 · arma pesada</option></select></label><label>Bônus adicional no ataque<input id="attack-extra" type="number" value="0"></label></div><button class="primary-btn full" id="roll-attack">Rolar ataque</button><p class="hint">O livro lista dano por peso da arma: leve 1d6, média 1d8 e pesada 1d12. Ajuste bônus ou efeitos especiais manualmente.</p></div></section>
    <section id="panel-dice" class="panel"><div class="section-heading"><div><div class="eyebrow">ROLAGENS</div><h2>Salão dos dados</h2></div></div><div class="panel-card"><div class="dice-buttons">${[4,6,8,10,12,20].map(n=>`<button class="die" data-die="${n}"><span>d${n}</span><small>Rolar</small></button>`).join("")}</div><div class="dice-custom"><label>Rolagem personalizada<input id="dice-expression" value="1d20+3" placeholder="Ex.: 2d8+2"></label><button class="primary-btn" id="roll-custom">Rolar</button></div><div class="roll-output"><span id="roll-result-label">ÚLTIMA ROLAGEM</span><strong id="roll-total">—</strong><small id="roll-breakdown">Escolha um dado para começar.</small></div></div><div class="panel-card"><h3>Teste de atributo / perícia</h3><div class="form-grid"><label>Personagem<select id="test-character"></select></label><label>Atributo<select id="test-attribute">${ATTRS.map(a=>`<option>${a}</option>`).join("")}</select></label><label>Bônus de perícia<input id="test-bonus" type="number" value="0"></label><label>Modificador adicional<input id="test-extra" type="number" value="0"></label></div><button class="primary-btn full" id="roll-test">Rolar teste (1d20)</button><p class="hint">Perícias: sem treino +0; treinado +2; experiente +3; perito +4. Some o modificador do atributo usado.</p></div></section>
    <section id="panel-conditions" class="panel"><div class="section-heading"><div><div class="eyebrow">ESTADOS E EFEITOS</div><h2>Condições de Aleória</h2></div></div><div class="panel-card"><label>Aplicar condição a<select id="condition-target"></select></label><div class="condition-filter"><input id="condition-search" placeholder="Buscar condição..."></div><div id="condition-grid" class="condition-grid"></div><p class="hint">As intensidades seguem o livro: Leve termina ao fim do próximo turno ou conforme a fonte; Média exige tratamento ou descanso longo; Crítica exige descanso longo e tratamento especializado. Três aplicações Leves podem escalar para Média.</p></div><div class="panel-card"><h3>Condições aplicadas</h3><div id="applied-conditions"></div></div></section>
  </main>
  <dialog id="character-modal" class="modal"><form id="character-form"><div class="modal-head"><div><div class="eyebrow">REGISTRO DE AVENTUREIRO</div><h2 id="character-modal-title">Nova ficha</h2></div><button type="button" class="icon-btn" id="close-modal">×</button></div><div id="character-fields"></div><div class="modal-actions"><button type="button" class="secondary-btn" id="cancel-modal">Cancelar</button><button class="primary-btn" type="submit">Salvar ficha</button></div></form></dialog>
  <dialog id="condition-modal" class="modal small-modal"><form id="condition-form"><div class="modal-head"><div><div class="eyebrow">APLICAR EFEITO</div><h2 id="condition-modal-name">Condição</h2></div><button type="button" class="icon-btn" id="close-condition">×</button></div><label>Intensidade<select name="level"><option>Leve</option><option>Média</option><option>Crítica</option></select></label><label>Duração / observação<input name="duration" placeholder="Ex.: 2 turnos, até tratamento..."></label><div class="modal-actions"><button type="button" class="secondary-btn" id="cancel-condition">Cancelar</button><button class="primary-btn">Aplicar condição</button></div></form></dialog>
  <footer><span>✦ ALEÓRIA RPG TOOLS</span><span>Feito para narrar histórias extraordinárias.</span></footer>
`;

// Navigation and forms
$(".tabs").addEventListener("click", e=>{const b=e.target.closest("[data-tab]");if(b) nav(b.dataset.tab);});
document.addEventListener("click", e=>{const goto=e.target.closest("[data-goto]");if(goto) nav(goto.dataset.goto);if(e.target.closest("#empty-add")) openCharacter();});
$("#new-character").onclick=$("#new-character-2").onclick=()=>openCharacter();

$("#close-modal").onclick=$("#cancel-modal").onclick=()=>$("#character-modal").close();
$("#character-list").addEventListener("click",e=>{
  const card=e.target.closest(".character-card"); if(!card)return; const c=state.characters.find(x=>x.id===card.dataset.id); if(!c)return;
  if(e.target.closest(".edit-char")) openCharacter(c);
  if(e.target.closest(".delete-char") && confirm(`Excluir a ficha de ${c.name}?`)){state.characters=state.characters.filter(x=>x.id!==c.id);state.initiative=state.initiative.filter(x=>x.characterId!==c.id);persist();render();}
  if(e.target.closest(".adjust")){const b=e.target.closest(".adjust"), key=b.dataset.resource; c[key]=Math.max(0,Math.min(Number(c[key==="pv"?"maxPv":"maxPe"]||999),Number(c[key]||0)+Number(b.dataset.delta)));addLog(`${c.name}: ${key.toUpperCase()} ${b.dataset.delta>0?"+":""}${b.dataset.delta}.`);persist();render();}
  if(e.target.closest(".add-init")){addInitiative(c.id);nav("initiative");}
  if(e.target.closest(".show-cond")){ $("#condition-target").value=c.id; nav("conditions"); }
  if(e.target.closest(".quick-roll")){ $("#test-character").value=c.id; nav("dice"); }
});
$("#character-form").addEventListener("submit",e=>{
  e.preventDefault(); const form=e.currentTarget, old=state.characters.find(x=>x.id===form.dataset.id); const data=Object.fromEntries(new FormData(form).entries());
  const next={...(old||{}),id:form.dataset.id,name:data.name.trim(),race:data.race,className:data.className,level:Number(data.level||1),...Object.fromEntries(ATTRS.map(a=>[a,Number(data[a]||10)])),...Object.fromEntries(["pv","maxPv","pe","maxPe","armorBonus","armorProf","reflexSkill","shieldBonus","baseMove","athletics","load","bagBonus","weaponProf","damageBonus"].map(k=>[k,Number(data[k]||0)])),heavyArmor:form.elements.heavyArmor.checked,conditions:old?.conditions||[]};
  next.pv=Math.min(next.pv,next.maxPv); next.pe=Math.min(next.pe,next.maxPe);
  if(old) state.characters=state.characters.map(c=>c.id===old.id?next:c); else state.characters.push(next);
  addLog(`Ficha de ${next.name} ${old?"atualizada":"criada"}.`);persist();render();form.closest("dialog").close();
});

$("#next-turn").onclick=nextTurn;
$("#new-round").onclick=()=>{state.round=1;state.active=0;addLog("Contagem de rodadas reiniciada.");persist();render();};
$("#clear-init").onclick=()=>{if(confirm("Limpar toda a ordem de iniciativa?")){state.initiative=[];state.active=0;state.round=1;persist();render();}};
$("#add-init-select").onclick=()=>{if(!state.characters.length){alert("Crie uma ficha primeiro.");return;}const id=prompt(`Digite o número do personagem:\n${state.characters.map((c,i)=>`${i+1}. ${c.name}`).join("\n")}`);const c=state.characters[Number(id)-1];if(c)addInitiative(c.id);};
$("#initiative-list").addEventListener("change",e=>{if(e.target.matches(".initiative-value")){const entry=state.initiative.find(x=>x.id===e.target.closest(".initiative-row").dataset.id);if(entry){entry.value=Number(e.target.value);state.initiative.sort((a,b)=>b.value-a.value);persist();render();}}});
$("#initiative-list").addEventListener("click",e=>{const b=e.target.closest(".remove-init");if(b){const row=b.closest(".initiative-row");state.initiative=state.initiative.filter(x=>x.id!==row.dataset.id);state.active=0;persist();render();}});
$("#roll-all-init").onclick=()=>{state.initiative=[];state.characters.forEach(c=>addInitiative(c.id));state.initiative.sort((a,b)=>b.value-a.value);state.active=0;persist();render();};

document.addEventListener("click",e=>{const die=e.target.closest("[data-die]");if(die){const sides=Number(die.dataset.die),result=rollDice(`1d${sides}`);showRoll(result,`Dado d${sides}`);}});
$("#roll-custom").onclick=()=>{const result=rollDice($("#dice-expression").value);if(!result){alert("Formato inválido. Use, por exemplo, 2d8+3.");return;}showRoll(result,"Rolagem personalizada");};
function refreshTestSelect(){const current=$("#test-character").value;$("#test-character").innerHTML=state.characters.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");if(state.characters.some(c=>c.id===current))$("#test-character").value=current;const ac=$("#attack-character"), old=ac.value;ac.innerHTML=state.characters.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");if(state.characters.some(c=>c.id===old))ac.value=old;}
$("#roll-test").onclick=()=>{const c=state.characters.find(x=>x.id===$("#test-character").value);if(!c){alert("Crie ou selecione um personagem.");return;}const attr=$("#test-attribute").value,bonus=mod(c[attr])+Number($("#test-bonus").value||0)+Number($("#test-extra").value||0);showRoll(rollDice(`1d20${bonus>=0?"+":""}${bonus}`),`Teste ${attr} · ${c.name}`);};
$("#roll-attack").onclick=()=>{const c=state.characters.find(x=>x.id===$("#attack-character").value);if(!c){alert("Crie ou selecione um personagem.");return;}const attr=$("#attack-attribute").value,bonus=mod(c[attr])+Number(c.weaponProf||0)+Number($("#attack-extra").value||0);const attack=rollDice(`1d20${bonus>=0?"+":""}${bonus}`);const damage=rollDice(`1d${$("#attack-die").value}${Number(c.damageBonus||0)>=0?"+":""}${Number(c.damageBonus||0)}`);showRoll(attack,`Ataque ${c.name}`);$("#roll-breakdown").textContent+=` · Dano: ${damage.expression} = ${damage.total} [${damage.rolls.join(" + ")}]`;addLog(`Dano de ${c.name}: ${damage.expression} = ${damage.total}.`);persist();renderLog();};

let selectedCondition=null;
$("#condition-grid").addEventListener("click",e=>{const b=e.target.closest("[data-condition]");if(!b)return;selectedCondition=b.dataset.condition;$("#condition-modal-name").textContent=selectedCondition;$("#condition-modal").showModal();});
$("#close-condition").onclick=$("#cancel-condition").onclick=()=>$("#condition-modal").close();
$("#condition-form").addEventListener("submit",e=>{e.preventDefault();const c=state.characters.find(x=>x.id===$("#condition-target").value);if(!c){alert("Selecione um personagem.");return;}const form=e.currentTarget;c.conditions=c.conditions||[];c.conditions.push({name:selectedCondition,level:form.elements.level.value,duration:form.elements.duration.value});addLog(`${selectedCondition} (${form.elements.level.value}) aplicado em ${c.name}.`);persist();render();form.closest("dialog").close();});
$("#applied-conditions").addEventListener("click",e=>{const b=e.target.closest("[data-remove-cond]");if(!b)return;const c=state.characters.find(x=>x.id===b.dataset.removeCond);if(c){c.conditions.splice(Number(b.dataset.index),1);persist();render();}});
$("#condition-search").addEventListener("input",e=>{const term=e.target.value.toLocaleLowerCase("pt-BR");document.querySelectorAll(".condition-chip").forEach(b=>b.hidden=!b.dataset.condition.toLocaleLowerCase("pt-BR").includes(term));});

// First render and Owlbear connection
render(); refreshTestSelect();
OBR.onReady(async()=>{
  obrReady=true;
  const ready=await OBR.scene.isReady();
  if(ready) await loadScene();
  OBR.scene.onReadyChange(async isReady=>{obrReady=isReady;if(isReady) await loadScene();else render();});
  OBR.scene.onMetadataChange(metadata=>{
    const incoming=metadata?.[META_KEY];
    if(incoming && !syncing){syncing=true;state=normalize(incoming);localStorage.setItem(LOCAL_KEY,JSON.stringify(state));render();refreshTestSelect();syncing=false;}
  });
  render();
});
